/**
 * The Java Developers Almanac 1.4
 * e638. Getting and Setting an Image on the System Clipboard
 * 
 * From: http://exampledepot.com/egs/java.awt.datatransfer/ToClipImg.html
 */
package graphics;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

public class ClipboardImage implements Transferable {

	private Image image;

	// Sets the image on the clipboard
	public static void setClipboard(Image image) {
		ClipboardImage img = new ClipboardImage(image);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(img, null);
	}

	// Constructor
	public ClipboardImage(Image image) {
		this.image = image;
	}

	// Returns supported flavors
	public DataFlavor[] getTransferDataFlavors() {
		return new DataFlavor[] { DataFlavor.imageFlavor };
	}

	// Returns true if flavor is supported
	public boolean isDataFlavorSupported(DataFlavor flavor) {
		return DataFlavor.imageFlavor.equals(flavor);
	}

	// Returns image
	public Object getTransferData(DataFlavor flavor)
			throws UnsupportedFlavorException, IOException {
		if (!DataFlavor.imageFlavor.equals(flavor)) {
			throw new UnsupportedFlavorException(flavor);
		}
		return image;
	}
}