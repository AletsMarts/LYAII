package graphics;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

/**
 * Implements a drawable panel.
 * 
 * @author Donadon
 */
public class Canvas extends JPanel {

	private static final long serialVersionUID = 1071197538601512414L;
	private BufferedImage buffer;
	private Graphics2D canvas;

	/**
	 * Default constructor.
	 */
	public Canvas(Dimension d) {
		resizeCanvas(d);
	}

	/**
	 * Paints this canvas after a buffered image.
	 */
	@Override
	public void paintComponent(Graphics g) {
		((Graphics2D) g).drawImage(buffer, null, 0, 0);
	}

	/**
	 * Returns the graphical object after which the canvas is painted.
	 * 
	 * @return the graphical object of the canvas
	 */
	public Graphics2D getCanvas() {
		return canvas;
	}

	public void resizeCanvas(Dimension d) {
		setPreferredSize(d);
		buffer = new BufferedImage((int) d.getWidth(), (int) d.getHeight(),
				BufferedImage.TYPE_INT_ARGB);
		canvas = (Graphics2D) buffer.getGraphics();
		canvas.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
	}
}
