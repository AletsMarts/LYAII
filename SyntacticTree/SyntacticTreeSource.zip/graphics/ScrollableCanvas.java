package graphics;

import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.JScrollPane;

/**
 * Implements a scrollable panel that contains a drawable canvas. A class
 * extending this one should implement the drawing procedure used in the canvas.
 * 
 * @author Donadon
 * @see Canvas
 */
public abstract class ScrollableCanvas extends JScrollPane {

	private static final long serialVersionUID = 1L;
	private Canvas canvas;

	/**
	 * Creates a scrollable panel for a canvas with the given dimensions.
	 * 
	 * @param xMin
	 *            width of the canvas
	 * @param yMin
	 *            height of the canvas
	 */
	public ScrollableCanvas(Dimension d) {
		super();
		canvas = new Canvas(d);
		getViewport().add(canvas);
		// getViewport().setViewPosition(new Point(10 + (xMax - xView) / 2, 10 +
		// (yMax - yView) / 2));
		getHorizontalScrollBar().setUnitIncrement(10);
		getVerticalScrollBar().setUnitIncrement(10);
		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent ce) {
				refresh();
			}
		});
	}

	/**
	 * Returns the minimum size of the panel. The use is obsecure.
	 * 
	 * @return the minimum dimension
	 */
	@Override
	public Dimension getMinimumSize() {
		return new Dimension(25, 25);
	}

	/**
	 * Returns the drawable panel used inside the scroller.
	 * 
	 * @return the drawable canas
	 */
	public Graphics2D getCanvas() {
		return canvas.getCanvas();
	}

	/**
	 * Redraws the canvas component of the panel. This function is automatically
	 * called when the component is resized.
	 */
	public void refresh() {
		draw(getCanvas());
		canvas.repaint();
	}

	public Dimension getCanvasSize() {
		return canvas.getPreferredSize();
	}

	/**
	 * Describes how the canvas panel should be painted. The graphical object is
	 * a buffered structure that is used whenever {@link #refresh()} is called.
	 * 
	 * @param go
	 *            the graphical object
	 */
	public abstract void draw(Graphics2D go);

	public void resizeCanvas(Dimension d) {
		canvas.resizeCanvas(d);
		revalidate();
		refresh();
		repaint();
	}
}