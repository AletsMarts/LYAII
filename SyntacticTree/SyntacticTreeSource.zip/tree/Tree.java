package tree;

import graphics.ClipboardImage;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Hashtable;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import text.RichEdit;
import text.TextToolkit;

abstract class Action {
	public static final int RETURN_NODE = 0;
	public static final int KEEP_ON = 1;
	public static final int SKIP_CHILDREN = 2;

	public abstract int execute(Node n);

	public static Node executeOnTree(Node start, Action a) {
		Vector<Node> list = new Vector<Node>();
		list.add(start);
		while (!list.isEmpty()) {
			Node n = list.remove(0);
			int result = a.execute(n);
			if (result == RETURN_NODE)
				return n;
			if (n.hasChild() && result != SKIP_CHILDREN)
				list.addAll(n.getChildren());
		}
		return null;
	}

	public static Node executeOnTree(Vector<Node> list, Action a) {
		for (Node n : list) {
			Node r = Action.executeOnTree(n, a);
			if (r != null)
				return r;
		}
		return null;
	}
}

public class Tree {

	public static final String DOC_DIMENSION = "dim";
	public static final String DOC_FONT = "font";
	public static final String DOC_GRID_WIDTH = "gw";
	public static final String DOC_GRID_HEIGHT = "gh";

	private Vector<Node> forest = new Vector<Node>();
	private Node selectedNode = null;
	private Node mergingNode = null;
	private Font defaultFont = new Font("Dialog", Font.PLAIN, 12);
	private boolean changed = false;

	public boolean hasChanged() {
		return changed;
	}

	private void markChange() {
		changed = true;
	}

	public Node executeOnForest(Action a) {
		return Action.executeOnTree(forest, a);
	}

	private Node createNewNode(Object doc) {
		Node n;
		if (doc instanceof StyledDocument)
			n = new Node((StyledDocument) doc);
		else if (doc instanceof String)
			n = new Node((String) doc);
		else
			return null;
		applyFont(n);
		markChange();
		return n;
	}

	public void addNewRoot(Point p, Object doc) {
		Node n = createNewNode(doc);
		n.setPoint(p);
		forest.add(n);
	}

	public void addNewChild(Object doc) {
		if (selectedNode == null)
			return;
		boolean hasNoChild = !selectedNode.hasChild();
		Node n = createNewNode(doc);
		selectedNode.addChild(n);
		if (hasNoChild)
			n.setPoint(new Point(selectedNode.getPoint().x, n.getPoint().y));
	}

	public void changeLabel(JFrame panel) {
		if (selectedNode == null)
			return;
		StyledDocument oldDoc = TextToolkit.copy(selectedNode.getText());
		RichEdit re = new RichEdit(panel, selectedNode.getText());
		if( !re.accepted() ) {
			selectedNode.setText(oldDoc);
		}
		boolean fontLost = selectedNode.getText().getLength() == 0;
		selectedNode.updateImage();
		if (fontLost) {
			applyFont(selectedNode);
		}
		markChange();
	}

	public void setNewPosition(Point p) {
		if (selectedNode == null)
			return;
		if (selectedNode.hasParent()) {
			Node parent = selectedNode.getParent();
			if (parent.getPoint().y >= p.y)
				p.y = selectedNode.getPoint().y;
			int i = parent.getChildren().indexOf(selectedNode);
			if (i > 0 && parent.getChildren().get(i - 1).getPoint().x >= p.x)
				p.x = selectedNode.getPoint().x;
			else if (i < (parent.getChildren().size() - 1)
					&& parent.getChildren().get(i + 1).getPoint().x <= p.x)
				p.x = selectedNode.getPoint().x;
		}
		selectedNode.setPoint(p);
		markChange();
	}

	public void removeFromTree() {
		if (selectedNode == null)
			return;
		selectedNode.separate();
		if (forest.contains(selectedNode))
			forest.remove(selectedNode);
		selectedNode = null;
		System.gc();
		markChange();
	}

	public Node detachFromTree() {
		if (selectedNode == null)
			return null;
		Node n = selectedNode.substitute();
		markChange();
		applyFont(n);
		if (forest.contains(selectedNode))
			forest.add(n);
		else
			forest.add(selectedNode);
		return n;
	}

	public boolean isThereSomeone(Point p) {
		mergingNode = executeOnForest(new SelectAction(p, selectedNode));
		return mergingNode != null;
	}

	public boolean isPossibleToMerge() {
		if (selectedNode == null || selectedNode.hasParent())
			return false;
		if (mergingNode == null || mergingNode.hasChild())
			return false;
		return true;
	}

	public void mergeInPosition() {
		if (!isPossibleToMerge())
			return;
		mergingNode.merge(selectedNode);
		forest.remove(selectedNode);
		selectedNode = mergingNode;
		mergingNode = null;
		System.gc();
		markChange();
	}

	private Node newXstructure(String x, boolean spec) {
		Node head = createNewNode(x + "P");
		Node inter = head;
		if (spec) {
			head.addChild(createNewNode("<spec>"));
			inter = createNewNode(x + "\'");
			head.addChild(inter);
		}
		Node leaf = createNewNode(x);
		Node leafChild = createNewNode("<head>"); 
		leaf.addChild(leafChild);
		leafChild.setPoint(new Point(leaf.getPoint().x, leafChild.getPoint().y));
		inter.addChild(leaf);
		inter.addChild(createNewNode("<comp>"));
		return head;
	}

	public void placeNewXstructure(String x, boolean spec) {
		if (!selectedNodeIsLeaf())
			return;
		selectedNode.merge(newXstructure(x, spec));
	}

	public void addNewXstructure(Point p, String x, boolean spec) {
		Node n = newXstructure(x, spec);
		n.setPoint(p);
		forest.add(n);
	}

	public void insertAdjunct() {
		if (selectedNode == null)
			return;
		Node n = selectedNode.substitute();
		n.setText(TextToolkit.copy(selectedNode.getText()));
		n.addChild(selectedNode);
		n.addChild(createNewNode("<adjunct>"));
		applyFont(n);
		if (forest.contains(selectedNode)) {
			forest.remove(selectedNode);
			forest.add(n);
		}
	}

	public void insertParent() {
		Node n = detachFromTree();
		if (n == null)
			return;
		n.addChild(selectedNode);
		selectedNode.setPoint(new Point(n.getPoint().x,
				selectedNode.getPoint().y));
		forest.remove(selectedNode);
	}

	public void setNodeCompacted(boolean v) {
		if (selectedNode == null)
			return;
		selectedNode.setCompacted(v);
		markChange();
	}

	public void addCompactedChild(Object doc) {
		if (selectedNode == null)
			return;
		addNewChild(doc);
		selectedNode.setCompacted(true);
	}

	public boolean removeNodeOnly() {
		if (selectedNode != null && selectedNode.removeNode(forest)) {
			selectedNode = null;
			markChange();
			return true;
		}
		return false;
	}

	private class SelectAction extends Action {
		private Point local;
		private boolean hardSearch;
		private int gw, gh;
		private Node thisNot = null;

		public SelectAction(Point p) {
			local = p;
			hardSearch = false;
		}

		public SelectAction(Point p, int x, int y) {
			this(p);
			gw = x;
			gh = y;
			hardSearch = true;
		}

		public SelectAction(Point p, Node n) {
			this(p);
			thisNot = n;
		}

		@Override
		public int execute(Node n) {
			int keepOp = n.isCompacted() ? SKIP_CHILDREN : KEEP_ON;
			if (n.equals(thisNot))
				return KEEP_ON;
			if (!hardSearch) {
				return (n.getPoint().x == local.x && n.getPoint().y == local.y) ? RETURN_NODE
						: keepOp;
			}
			if (n.getText().getLength() == 0)
				return keepOp;
			BufferedImage img = n.getImage();
			int x = n.getPoint().x * gw - img.getWidth() / 2;
			int y = n.getPoint().y * gh - gh / 2;
			Rectangle r = new Rectangle(x, y, img.getWidth(), img.getHeight());
			return r.contains(local) ? RETURN_NODE : keepOp;
		}
	}

	public void selectNode(Point p, Point ep, int x, int y) {
		selectedNode = executeOnForest(new SelectAction(p));
		if (selectedNode == null)
			selectedNode = executeOnForest(new SelectAction(ep, x, y));
	}

	public boolean hasNodeSelected() {
		return selectedNode != null;
	}

	public boolean selectedNodeIsLeaf() {
		return hasNodeSelected() && !selectedNode.hasChild();
	}

	private class CompactedDimensioAction extends Action {
		private Dimension dim;

		public CompactedDimensioAction() {
			dim = new Dimension(0, 0);
		}

		@Override
		public int execute(Node n) {
			if (n.hasChild())
				return KEEP_ON;
			BufferedImage img = n.getImage();
			int h = img.getHeight(), w = img.getWidth();
			if (h > dim.height)
				dim.height = h;
			dim.width += w;
			return KEEP_ON;
		}

		public Dimension getDimension() {
			return dim;
		}
	}

	private class CompactedImageAction extends Action {
		private BufferedImage composition;
		private Graphics2D canvas;
		private Dimension dim;
		private int xPos;

		public CompactedImageAction(Dimension d) {
			dim = d;
			composition = new BufferedImage(dim.width, dim.height,
					BufferedImage.TYPE_INT_ARGB);
			canvas = composition.createGraphics();
			xPos = 0;
		}

		@Override
		public int execute(Node n) {
			if (n.hasChild())
				return KEEP_ON;
			BufferedImage img = n.getImage();
			int w = img.getWidth();
			canvas.drawImage(img, null, xPos, 0);
			xPos += w;
			return KEEP_ON;
		}

		public BufferedImage getImage() {
			return composition;
		}
	}

	private class DrawAction extends Action {
		private Graphics2D canvas;
		private BufferedImage nullImg;
		private int gw, gh;
		private boolean toExport;
		private Rectangle border = null;

		public DrawAction(Graphics2D g, int w, int h, boolean v) {
			canvas = g;
			gw = w;
			gh = h;
			toExport = v;
		}

		@Override
		public int execute(Node n) {
			Point p = n.getPoint();
			int x, y;

			BufferedImage img = nullImg;
			img = n.getImage();
			x = p.x * gw - img.getWidth() / 2;
			y = p.y * gh - gh / 2;

			canvas.drawImage(img, null, x, y);
			if (toExport) {
				if (border == null)
					border = new Rectangle(x, y, img.getWidth(), img
							.getHeight());
				else
					border.add(new Rectangle(x, y, img.getWidth(), img
							.getHeight()));
			}
			if (!toExport && n.equals(selectedNode)) {
				if (n.isCompacted())
					canvas.setColor(new Color(0xFF, 0x70, 0x70, 0x50));
				else
					canvas.setColor(new Color(0xA0, 0xA0, 0xFF, 0x70));
				canvas.fillRect(x, y, img.getWidth(), img.getHeight());
			}

			int yDot = y + img.getHeight();
			canvas.setColor(Color.black);
			if (!n.isCompacted()) {
				for (Node c : n.getChildren()) {
					int cx = c.getPoint().x * gw;
					int cy = c.getPoint().y * gh - gh / 2;
					canvas.drawLine(p.x * gw, yDot, cx, cy);
				}
			} else if (n.hasChild()) {
				CompactedDimensioAction cda = new CompactedDimensioAction();
				executeOnTree(n.getChildren(), cda);
				CompactedImageAction cia = new CompactedImageAction(cda
						.getDimension());
				executeOnTree(n.getChildren(), cia);
				BufferedImage comp = cia.getImage();

				int cx = p.x * gw - comp.getWidth() / 2;
				int cy = (p.y + 2) * gh - gh / 2;

				Polygon tri = new Polygon();
				tri.addPoint(p.x * gw, yDot);
				tri.addPoint(p.x * gw - gw, cy);
				tri.addPoint(p.x * gw + gw, cy);
				canvas.drawPolygon(tri);
				canvas.drawImage(comp, null, cx, cy);
				if (toExport) {
					border.add(p.x * gw - gw, cy);
					border.add(p.x * gw + gw, cy);
					border.add(new Rectangle(cx, cy, comp.getWidth(), comp
							.getHeight()));
				}
				return SKIP_CHILDREN;
			}
			return KEEP_ON;
		}

		public Rectangle getBorder() {
			return border;
		}
	}

	public void draw(Graphics2D g, int gw, int gh) {
		executeOnForest(new DrawAction(g, gw, gh, false));
	}

	private void applyFont(Node n) {
		StyledDocument doc = n.getText();
		if (doc.getLength() == 0)
			n.updateImage();
		MutableAttributeSet s = new SimpleAttributeSet();
		StyleConstants.setFontFamily(s, defaultFont.getFamily());
		StyleConstants.setFontSize(s, defaultFont.getSize());
		doc.setCharacterAttributes(0, doc.getLength(), s, false);
		n.updateImage();
	}

	private class ChangeFontAction extends Action {
		@Override
		public int execute(Node n) {
			applyFont(n);
			return KEEP_ON;
		}
	}

	public void setFont(Font f) {
		defaultFont = f;
		executeOnForest(new ChangeFontAction());
	}

	public Font getFont() {
		return defaultFont;
	}

	public void newTree() {
		forest.removeAllElements();
		selectedNode = null;
		defaultFont = new Font("Dialog", Font.PLAIN, 12);
		System.gc();
		changed = false;
	}

	public void save(File f, Dimension d, int gw, int gh) throws Exception {
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(d);
		oos.writeObject(defaultFont);
		oos.writeInt(gw);
		oos.writeInt(gh);
		oos.writeObject(forest);
		oos.close();
		changed = false;
	}

	@SuppressWarnings("unchecked")
	public Hashtable<String, Object> open(File f) throws Exception {
		Hashtable<String, Object> map = new Hashtable<String, Object>();
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
		map.put(DOC_DIMENSION, ois.readObject());
		Object o = ois.readObject();
		if (o instanceof Font) {
			defaultFont = (Font) o;
			map.put(DOC_FONT, defaultFont);
		} else
			throw new Exception("Error on reading serialized font!");
		map.put(DOC_GRID_WIDTH, new Integer(ois.readInt()));
		map.put(DOC_GRID_HEIGHT, new Integer(ois.readInt()));
		o = ois.readObject();
		if (o instanceof Vector) {
			forest = (Vector<Node>) o;
			selectedNode = null;
			System.gc();
			changed = false;
			return map;
		} else {
			throw new Exception("Error on reading serialized vector!");
		}
	}

	private BufferedImage createLocalImage(Dimension cDim, int gw, int gh) {
		BufferedImage bi = new BufferedImage(cDim.width, cDim.height,
				BufferedImage.TYPE_INT_RGB);
		Graphics2D g = bi.createGraphics();
		g.setBackground(Color.WHITE);
		g.clearRect(0, 0, bi.getWidth(), bi.getHeight());
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		DrawAction da = new DrawAction(g, gw, gh, true);
		executeOnForest(da);
		Rectangle r = da.getBorder();
		if (r != null)
			return bi.getSubimage(r.x, r.y, r.width, r.height);
		else
			return null;
	}

	public void copyToClipboard(Dimension cDim, int gw, int gh) {
		BufferedImage bi = createLocalImage(cDim, gw, gh);
		if (bi != null)
			ClipboardImage.setClipboard(bi);
	}

	public void exportImage(Dimension cDim, int gw, int gh, File f, String type)
			throws Exception {
		BufferedImage bi = createLocalImage(cDim, gw, gh);
		FileOutputStream fos = new FileOutputStream(f);
		ImageIO.write(bi, type, fos);
		fos.close();
	}
}
