package tree;

import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Vector;

import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyledDocument;

import text.TextToolkit;

public class Node implements Serializable {

	private static final long serialVersionUID = -2440546905605212185L;
	private StyledDocument doc;
	private Vector<Node> children = new Vector<Node>();
	private Node parent = null;
	private Point loc;
	private boolean compacted;
	private BufferedImage image;

	private Node() {
		loc = new Point(0, 0);
		compacted = false;
	}

	public Node(String s) {
		this();
		try {
			doc = new DefaultStyledDocument();
			doc.insertString(0, s, new SimpleAttributeSet());
			updateImage();
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
	}

	public Node(StyledDocument d) {
		this();
		doc = d;
		updateImage();
	}

	public void addChild(Node n) {
		if (n.hasParent())
			return;
		n.parent = this;
		if (!hasChild())
			n.loc = new Point(-2, 2);
		else
			n.loc = new Point(children.lastElement().loc.x + 4, 2);
		children.add(n);
	}

	public void separate() {
		if (hasParent()) {
			parent.children.remove(this);
			loc = getPoint();
			parent = null;
		}
	}

	public Node substitute() {
		Node n = new Node("");
		n.loc = new Point(loc);
		if (hasParent()) {
			int i = parent.children.indexOf(this);
			n.parent = parent;
			separate();
			n.parent.children.insertElementAt(n, i);
		}
		loc.y += 2;
		return n;
	}

	public void merge(Node n) {
		if (hasChild() || n.hasParent())
			return;
		children = n.children;
		for (Node c : children)
			c.parent = this;
		doc = n.doc;
		image = n.image;
		compacted = n.compacted;
	}

	public boolean removeNode(Vector<Node> forest) {
		if (!hasParent()) {
			forest.remove(this);
			for (Node n : children) {
				n.loc = n.getPoint();
				n.parent = null;
				forest.add(n);
			}
			return true;
		} else if (!hasChild()) {
			parent.children.remove(this);
			return true;
		} else if (children.size() <= 1) {
			if (hasChild()) {
				Node c = children.firstElement();
				parent.children.set(parent.children.indexOf(this), c);
				c.parent = parent;
				c.loc = this.loc;
			}
			return true;
		}
		return false;
	}

	public void updateImage() {
		if (doc.getLength() <= 0) {
			try {
				doc.insertString(0, "" + (char) 0x00D8,
						new SimpleAttributeSet());
			} catch (Exception e) {
				e.printStackTrace(System.err);
			}
		}
		image = TextToolkit.convert(doc);
	}

	public StyledDocument getText() {
		return doc;
	}

	public void setText(StyledDocument d) {
		doc = d;
	}

	public BufferedImage getImage() {
		return image;
	}

	public Point getPoint() {
		if (hasParent())
			return new Point(loc.x + parent.getPoint().x, loc.y
					+ parent.getPoint().y);
		else
			return loc;
	}

	public void setPoint(Point loc) {
		if (hasParent())
			this.loc = new Point(loc.x - parent.getPoint().x, loc.y
					- parent.getPoint().y);
		else
			this.loc = loc;
	}

	public Vector<Node> getChildren() {
		return children;
	}

	public boolean hasChild() {
		return !children.isEmpty();
	}

	public Node getParent() {
		return parent;
	}

	public boolean hasParent() {
		return parent != null;
	}

	public boolean isCompacted() {
		return compacted;
	}

	public void setCompacted(boolean compacted) {
		this.compacted = compacted;
	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		out.writeObject(doc);
		out.writeObject(children);
		out.writeObject(parent);
		out.writeObject(loc);
		out.writeBoolean(compacted);
	}

	@SuppressWarnings("unchecked")
	private void readObject(ObjectInputStream in) throws IOException,
			ClassNotFoundException {
		doc = (StyledDocument) in.readObject();
		children = (Vector<Node>) in.readObject();
		parent = (Node) in.readObject();
		loc = (Point) in.readObject();
		compacted = in.readBoolean();
		updateImage();
	}
}
