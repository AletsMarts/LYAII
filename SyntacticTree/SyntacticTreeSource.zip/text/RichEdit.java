package text;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.util.Hashtable;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.JToggleButton;
import javax.swing.ListCellRenderer;
import javax.swing.ScrollPaneConstants;
import javax.swing.colorchooser.AbstractColorChooserPanel;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

class ComboBoxRenderer extends JLabel implements ListCellRenderer {

	public static String[] stringSet = new String[] { "Left", "Center", "Right" };
	private static final long serialVersionUID = -7513108034563921671L;
	private Icon[] iconSet = new Icon[] {
			new ImageIcon(getClass().getResource("/icons/AlignLeft16.gif")),
			new ImageIcon(getClass().getResource("/icons/AlignCenter16.gif")),
			new ImageIcon(getClass().getResource("/icons/AlignRight16.gif")) };
	public ComboBoxRenderer() {
		setOpaque(true);
		setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
	}

	@Override
	public Component getListCellRendererComponent(JList list, Object value,
			int index, boolean isSelected, boolean cellHasFocus) {
		if (isSelected) {
			setBackground(list.getSelectionBackground());
			setForeground(list.getSelectionForeground());
		} else {
			setBackground(list.getBackground());
			setForeground(list.getForeground());
		}

		for(int i = 0; i < stringSet.length; i++ )
			if(value.equals(stringSet[i]) )
				setIcon(iconSet[i]);
		setText((String) value);
		setFont(list.getFont());
		return this;
	}
}

class Preview extends JPanel implements ChangeListener {

	private static final long serialVersionUID = -9037012782136414197L;
	private JTextPane tp;
	private MutableAttributeSet att;
	private JColorChooser color;
	private Graphics2D rect;
	private final static int DIM = 20;

	public Preview(JColorChooser c) {
		super(new BorderLayout());
		color = c;
		tp = new JTextPane();
		add(tp, BorderLayout.CENTER);
		tp.setText("The brown fox jumped the lazy dog");
		tp.setEditable(false);
		tp.setFocusable(false);

		att = new SimpleAttributeSet();
		StyleConstants.setAlignment(att, StyleConstants.ALIGN_CENTER);
		StyleConstants.setFontSize(att, 12);
		StyleConstants.setBold(att, true);
		StyleConstants.setFontFamily(att, "SansSerif");
		tp.setParagraphAttributes(att, true);

		BufferedImage bi = new BufferedImage(DIM, DIM,
				BufferedImage.TYPE_INT_RGB);
		rect = bi.createGraphics();
		JLabel l1 = new JLabel(new ImageIcon(bi));
		JLabel l2 = new JLabel(new ImageIcon(bi));
		l1.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
		l2.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
		add(l1, BorderLayout.WEST);
		add(l2, BorderLayout.EAST);
		setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		StyleConstants.setForeground(att, color.getColor());
		tp.setParagraphAttributes(att, true);

		rect.setBackground(color.getColor());
		rect.clearRect(0, 0, DIM, DIM);
	}
}

public class RichEdit extends JDialog implements ActionListener, CaretListener, KeyListener {

	private static final long serialVersionUID = 1714435582722190333L;
	private StyledDocument doc;
	private Hashtable<String, JToggleButton> buttons = new Hashtable<String, JToggleButton>();
	private String[] label = new String[] { "B", "I", "U", "S" };
	private String[] tooltip = new String[] { "Bold", "Italic", "Underline",
			"Subscript" };
	private Icon[] icon = new Icon[] {
			new ImageIcon(getClass().getResource("/icons/bold16.gif")),
			new ImageIcon(getClass().getResource(
					"/icons/italic16.gif")),
			new ImageIcon(getClass().getResource(
					"/icons/underline16.gif")),
			new ImageIcon(getClass().getResource("/icons/font16.gif")) };
	private int[] keyStroke = new int[] { KeyEvent.VK_B, 
			KeyEvent.VK_I, KeyEvent.VK_U, KeyEvent.VK_S };
	private JButton btnColor = new JButton(new ImageIcon(getClass()
			.getResource("/icons/color.gif")));

	private JComboBox cmbAllign = new JComboBox(ComboBoxRenderer.stringSet);
	private JButton btnOkay = new JButton("Accept");
	private JTextPane text = new JTextPane();
	private static JColorChooser colorPnl;
	private boolean hasBeenCommited = false;
	private Hashtable<Integer, JToggleButton> actionHash = new Hashtable<Integer, JToggleButton>();
	// private UndoManager undoer = new UndoManager();

	static {
		colorPnl = new JColorChooser();
		Preview prev = new Preview(colorPnl);
		colorPnl.setChooserPanels(new AbstractColorChooserPanel[] { colorPnl
				.getChooserPanels()[0] });
		colorPnl.setPreviewPanel(null);
		colorPnl.setPreviewPanel(prev);
		colorPnl.getSelectionModel().addChangeListener(prev);
	}

	public RichEdit(JFrame root, StyledDocument d) {
		super(root, "Edit the text", true, null);
		doc = d;
		text.setStyledDocument(doc);
		text.selectAll();
		text.addCaretListener(this);
		text.addKeyListener(this);
		text.setName("text");
		/*
		InputMap mapKey = text.getInputMap();
		ActionMap mapAction = text.getActionMap();
		*/
		
		JPanel pTop = new JPanel(new FlowLayout(FlowLayout.LEADING, 5, 5));

		cmbAllign.setRenderer(new ComboBoxRenderer());
		// cmbAllign.setPreferredSize(new Dimension(cmbAllign.getWidth(), 26));
		cmbAllign.setFocusable(false);
		cmbAllign.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int s = ((JComboBox) e.getSource()).getSelectedIndex();
				MutableAttributeSet att = new SimpleAttributeSet();
				StyleConstants.setAlignment(att,
						(s == 0 ? StyleConstants.ALIGN_LEFT
								: (s == 1 ? StyleConstants.ALIGN_CENTER
										: StyleConstants.ALIGN_RIGHT)));
				try {
					text.setParagraphAttributes(att, false);
				} catch (Exception exp) {
				}
			}
		});
		pTop.add(cmbAllign);

		int i;
		for (i = 0; i < label.length; i++) {
			JToggleButton b = new JToggleButton(icon[i], false);
			b.setName(label[i]);
			b.setPreferredSize(new Dimension(26, 26));
			b.setToolTipText(tooltip[i]);
			b.addActionListener(this);
			b.setFocusable(false);
			pTop.add(b);
			//b.setAction(this);
			buttons.put(label[i], b);
			actionHash.put(new Integer(keyStroke[i]), b);

			//mapKey.put(keyStroke[i], label[i]);
			//mapAction.put(label[i], this);		
		}

		btnColor.setName("COLOR");
		btnColor.setToolTipText("Color");
		btnColor.setPreferredSize(new Dimension(26, 26));
		pTop.add(btnColor);
		btnColor.setFocusable(false);
		btnColor.addActionListener(this);

		JPanel pBottom = new JPanel(new FlowLayout(FlowLayout.TRAILING, 5, 5));
		JButton btnCancel = new JButton("Cancel");
		pBottom.add(btnCancel);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		pBottom.add(btnOkay);
		btnOkay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hasBeenCommited = true;
				dispose();
			}
		});
		
		JPanel pText = new JPanel(new BorderLayout());
		pText.setPreferredSize(new Dimension(200, 70));
		pText.add(new JScrollPane(text,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER), BorderLayout.CENTER);
		pText.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		getContentPane().add(pTop, BorderLayout.NORTH);
		getContentPane().add(pText, BorderLayout.CENTER);
		getContentPane().add(pBottom, BorderLayout.SOUTH);

		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setLocationRelativeTo(root);

		text.requestFocusInWindow();
		setVisible(true);
	}

	public boolean accepted() {
		return hasBeenCommited;
	}

	private void applyNewStyle(char op, MutableAttributeSet style, Color c,
			boolean v) {
		if (op == 'C' && c != null)
			StyleConstants.setForeground(style, c);
		else {
			switch (op) {
			case 'B':
				StyleConstants.setBold(style, v);
				break;
			case 'I':
				StyleConstants.setItalic(style, v);
				break;
			case 'U':
				StyleConstants.setUnderline(style, v);
				break;
			case 'S':
				StyleConstants.setSubscript(style, v);
				break;
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			String name = ((Component) e.getSource()).getName();
			
			// Determines the element(s) selected
			int str = text.getSelectionStart(), end = text.getSelectionEnd();
			if (str > end) {
				str = end;
				end = text.getSelectionStart();
			}
			int rep = (str + end) / 2; // Chooses a representative style
			if (str == end && rep > 0) // If there is no selection, previous
										// chat is rep
				rep--;
			if (rep >= doc.getLength() && rep > 0) { // If at the end of line,
														// last char is rep
				rep = doc.getLength() - 1;
			}
			MutableAttributeSet base = new SimpleAttributeSet(doc
					.getCharacterElement(rep).getAttributes());
			boolean newValue = false;
			Color newColor = null;

			// Information for new style
			if (name.compareTo("COLOR") == 0) {
				colorPnl.setColor(StyleConstants.getForeground(base));

				JDialog jd = JColorChooser.createDialog(this,
						"Choose text color", true, colorPnl,
						new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								setName("YES");
							}
						}, null);
				jd.setVisible(true);
				jd.dispose();
				if (getName().compareTo("YES") == 0) {
					newColor = colorPnl.getColor();
				} else
					return;
			} else {
				switch (name.charAt(0)) {
				case 'B':
					newValue = !StyleConstants.isBold(base);
					break;
				case 'I':
					newValue = !StyleConstants.isItalic(base);
					break;
				case 'U':
					newValue = !StyleConstants.isUnderline(base);
					break;
				case 'S':
					newValue = !StyleConstants.isSubscript(base);
					break;
				}
			}

			// Apply new style to each character on selection
			if (str == end) {
				applyNewStyle(name.charAt(0), base, newColor, newValue);
				text.setCharacterAttributes(base, true);
			} else {
				int i;
				for (i = str; i < end; i++) {
					base = new SimpleAttributeSet(doc.getCharacterElement(i)
							.getAttributes());
					applyNewStyle(name.charAt(0), base, newColor, newValue);
					doc.setCharacterAttributes(i, 1, base, true);
				}
			}
		} catch (Exception exc) {
			exc.printStackTrace(System.err);
		}
	}

	@Override
	public void caretUpdate(CaretEvent e) {
		int str = text.getSelectionStart(), end = text.getSelectionEnd();
		if (str > end) {
			str = end;
			end = text.getSelectionStart();
		}
		int rep = (str + end) / 2;
		if (str == end && rep > 0)
			rep--;
		if (rep >= doc.getLength() && rep > 0)
			rep = doc.getLength() - 1;
		AttributeSet style = new SimpleAttributeSet(doc
				.getCharacterElement(rep).getAttributes());
		buttons.get("B").setSelected(StyleConstants.isBold(style));
		buttons.get("I").setSelected(StyleConstants.isItalic(style));
		buttons.get("U").setSelected(StyleConstants.isUnderline(style));
		buttons.get("S").setSelected(StyleConstants.isSubscript(style));

		style = text.getParagraphAttributes();
		int i = StyleConstants.getAlignment(style);
		cmbAllign.setSelectedIndex(i == StyleConstants.ALIGN_LEFT ? 0
				: (i == StyleConstants.ALIGN_CENTER ? 1 : 2));
	}

	@Override
	public void keyPressed(KeyEvent k) {
		if(k.getModifiers() == ActionEvent.CTRL_MASK) {
			int c = k.getKeyCode();
			if( actionHash.keySet().contains(new Integer(c)) ) {
				actionHash.get(new Integer(c)).doClick(1);
			}
			else if( c == KeyEvent.VK_F) {
				buttons.get("S").doClick(1);
			}
			else if( c == KeyEvent.VK_ENTER) {
				btnOkay.doClick();
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// Not implemented
	}

	@Override
	public void keyTyped(KeyEvent k) {
		// Not implemented
	}
}
