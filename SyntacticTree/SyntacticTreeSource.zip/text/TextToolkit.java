package text;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

import javax.swing.JTextPane;
import javax.swing.JWindow;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Element;
import javax.swing.text.StyledDocument;

public class TextToolkit {

	public static StyledDocument copy(StyledDocument doc) {
		StyledDocument newDoc = new DefaultStyledDocument();
		for (int i = 0; i < doc.getLength(); i++) {
			Element e = doc.getCharacterElement(i);
			try {
				newDoc.insertString(i, doc.getText(i, 1), e.getAttributes());
			} catch (Exception exc) {
				System.err.println("Copy didnt work!");
				exc.printStackTrace(System.err);
			}
		}
		return newDoc;
	}

	public static BufferedImage convert(StyledDocument doc) {
		JWindow ghost = new JWindow();
		JTextPane cont = new JTextPane(doc);
		ghost.getContentPane().add(cont);
		ghost.pack();
		BufferedImage image = new BufferedImage(cont.getWidth(), cont
				.getHeight(), BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = image.createGraphics();
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		cont.setOpaque(false);
		cont.paint(g);
		g.dispose();
		ghost.dispose();
		return image;
	}
}
