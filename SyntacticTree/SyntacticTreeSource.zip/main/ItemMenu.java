package main;

import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class ItemMenu {
	public String title;
	public String name;
	public String url = null;
	public ItemMenu[] sub = null;

	public ItemMenu() {
		this("-", "-");
	}

	public ItemMenu(String t, String n) {
		title = t;
		name = n;
		url = null;
	}

	public ItemMenu(String t, String n, String u) {
		this(t, n);
		url = u;
	}

	public ItemMenu(String t, String n, ItemMenu[] i) {
		this(t, n);
		sub = i;
	}

	public boolean isSeparator() {
		return name.compareTo("-") == 0;
	}

	public JMenuItem createMenu(ActionListener al) {
		if (sub == null) {
			JMenuItem m = new JMenuItem(title);
			m.setName(name);
			if (url != null)
				m.setIcon(new ImageIcon(getClass().getResource(url)));
			m.addActionListener(al);
			return m;
		} else {
			JMenu m = new JMenu(title);
			for (ItemMenu i : sub) {
				if (i.isSeparator())
					m.addSeparator();
				else
					m.add(i.createMenu(al));
			}
			return m;
		}
	}
}