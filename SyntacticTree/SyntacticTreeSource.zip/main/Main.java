/*
 * Options to feature:
 * - [opt] Non formatted entering text for agility
 * - [opt] Use of "_" to signify subscript (only on unformatted text)
 * - palette of symbols
 * - help edition
 * - label about dimension of doc
 * - movable compacted node
 * - documentation of the code!!!
 */

package main;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.Hashtable;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;

import tree.Tree;

class DimensionDialog extends JDialog implements ActionListener {

	private static final long serialVersionUID = -1834204320446746054L;
	private Dimension dim;
	private boolean changed = false;
	private JTextField txtWidth = new JTextField();
	private JTextField txtHeight = new JTextField();

	private JPanel constructField(String text, JTextField field, int num) {
		JPanel p = new JPanel(new GridLayout(1, 2, 5, 5));
		p.add(new JLabel(text, JLabel.RIGHT));
		p.add(field);
		field.setText(Integer.toString(num));
		return p;
	}

	public DimensionDialog(JFrame root, Dimension d) {
		super(root, "Dimension", true, null);
		dim = d;
		getContentPane().setLayout(new BorderLayout());
		
		JPanel pnlFields = new JPanel(new GridLayout(2, 1, 5, 5));
		pnlFields.add(constructField("Width:", txtWidth, dim.width));
		pnlFields.add(constructField("Height:", txtHeight, dim.height));
		pnlFields.setBorder(BorderFactory
				.createTitledBorder("Grid's dimension"));
		getContentPane().add(pnlFields, BorderLayout.CENTER);

		JPanel pnlButtons = new JPanel(
				new FlowLayout(FlowLayout.TRAILING, 5, 5));
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(this);
		pnlButtons.add(btnCancel);

		JButton btnAccept = new JButton("Apply");
		btnAccept.addActionListener(this);
		pnlButtons.add(btnAccept);
		getContentPane().add(pnlButtons, BorderLayout.SOUTH);
		getRootPane().setDefaultButton(btnAccept);

		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setLocationRelativeTo(root);
		setVisible(true);
	}

	public Dimension getDimension() {
		return dim;
	}

	public boolean hasChanged() {
		return changed;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (((JButton) e.getSource()).getText().compareToIgnoreCase("apply") == 0) {
			try {
				dim = new Dimension(Integer.valueOf(txtWidth.getText()),
						Integer.valueOf(txtHeight.getText()));
				changed = true;
			} catch (Exception exc) {
				JOptionPane.showMessageDialog(this, "Bad formed number!",
						"Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		dispose();
	}
}

public class Main extends JFrame implements ActionListener, ChangeListener {

	private static final String GRID_WIDTH = "gridHor";
	private static final String GRID_HEIGHT = "gridVert";
	private static final String DOC_NEW = "docNew";
	private static final String DOC_OPEN = "docOpen";
	private static final String DOC_SAVE = "docSave";
	private static final String DOC_SAVE_AS = "docSaveAs";
	private static final String DOC_EXPORT = "docExport";
	private static final String COPY = "copy";
	private static final String RESIZE = "resize";
	// private static final String PREFERENCES = "pref";
	private static final String HELP = "help";
	private static final String ABOUT = "about";
	private static final String EXIT = "exit";

	private static final long serialVersionUID = 1633449875466245343L;
	private Tree tree = new Tree();
	private GridPanel gridPanel;
	private JComboBox fontCombo = new JComboBox();
	private JComboBox sizeCombo = new JComboBox();
	static final String[] sizeNames = new String[] { "8", "9", "10", "11",
			"12", "13", "14", "16", "18", "20", "22", "24", "26", "28", "32" };
	private Hashtable<String, JSlider> sliders = new Hashtable<String, JSlider>();
	private File workFile;
	private JLabel labelDim = new JLabel();

	private static final String mainTitle = "Syntactic Tree Designer - ";
	private static final String sizeText = "Document size: ";
	private static final int gridDefaultValue = 20;
	private static final Dimension defaultDocSize = new Dimension(560, 500);

	private JPanel createSlider(String label, String name) {
		JPanel p = new JPanel(new BorderLayout());
		p.add(new JLabel(label), BorderLayout.WEST);
		JSlider s = new JSlider(5, 55, gridDefaultValue);
		s.setPreferredSize(new Dimension(100, 30));
		s.setName(name);
		s.addChangeListener(this);
		s.setMajorTickSpacing(25);
		s.setMinorTickSpacing(5);
		s.setPaintTicks(true);
		p.add(s, BorderLayout.CENTER);
		sliders.put(name, s);
		return p;
	}

	private void insertButton(JPanel p, String name, String url, String label) {
		JButton b = new JButton(new ImageIcon(getClass().getResource(url)));
		b.setName(name);
		b.setToolTipText(label);
		b.addActionListener(this);
		b.setPreferredSize(new Dimension(26, 26));
		b.setFocusable(false);
		p.add(b);
	}

	private void changeFont() {
		int size = 12;
		try {
			size = Integer.valueOf((String) sizeCombo.getSelectedItem());
		} catch (Exception e) {
			return;
		}
		tree.setFont(new Font((String) fontCombo.getSelectedItem(), Font.PLAIN,
				size));
		gridPanel.refresh();
	}

	private JPanel createFontChooser() {
		JPanel p = new JPanel(new FlowLayout());
		p.add(new JLabel("Font:"));
		String[] fontFamilies = new String[] { "Dialog", "Monospaced", "Serif",
				"SansSerif" };
		fontCombo = new JComboBox(fontFamilies);
		fontCombo.setEditable(false);
		fontCombo.setSelectedItem("Dialog");
		fontCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				changeFont();
			}
		});
		fontCombo.setFocusable(false);
		p.add(fontCombo);

		p.add(new JLabel("Size:"));
		sizeCombo = new JComboBox(sizeNames);
		sizeCombo.setEditable(false);
		sizeCombo.setSelectedItem("12");
		sizeCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				changeFont();
			}
		});
		sizeCombo.setFocusable(false);
		p.add(sizeCombo);
		return p;
	}

	public Main() {
		setTitle(mainTitle + "New file");
		setIconImage(new ImageIcon(getClass().getResource(
				"/icons/graphics-32x32.png")).getImage());
		workFile = null;

		JPanel pSouth = new JPanel(new BorderLayout());
		labelDim.setAlignmentX(JLabel.RIGHT_ALIGNMENT);
		labelDim.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		pSouth.add(labelDim, BorderLayout.EAST);
		JPanel pGrid = new JPanel(new FlowLayout(FlowLayout.LEADING, 5, 2));
		pGrid.add(new JLabel(new ImageIcon(getClass().getResource(
				"/icons/view-fullscreen.png"))));
		pGrid.add(createSlider("Width:", GRID_WIDTH));
		pGrid.add(createSlider("Height:", GRID_HEIGHT));
		pSouth.add(pGrid, BorderLayout.CENTER);
		getContentPane().add(pSouth, BorderLayout.SOUTH);

		JPanel pNorth = new JPanel(new FlowLayout(FlowLayout.LEADING, 5, 2));
		insertButton(pNorth, DOC_NEW, "/icons/new16.gif", "New");
		insertButton(pNorth, DOC_OPEN, "/icons/open16.gif", "Open");
		insertButton(pNorth, DOC_SAVE, "/icons/save16.gif", "Save");
		pNorth.add(createFontChooser());
		insertButton(pNorth, COPY, "/icons/copy16.gif", "Copy to clipboard");
		// insertButton(pNorth, PREFERENCES, "/icons/hammer16.gif", "Preferences");

		getContentPane().add(pNorth, BorderLayout.NORTH);

		gridPanel = new GridPanel(this, defaultDocSize, tree);
		gridPanel.setGridHeight(gridDefaultValue);
		gridPanel.setGridWidth(gridDefaultValue);
		gridPanel.setFocusable(true);
		gridPanel.requestFocus();
		labelDim.setText(sizeText + defaultDocSize.width + " x " + defaultDocSize.height);
		getContentPane().add(gridPanel, BorderLayout.CENTER);

		JMenuBar bar = new JMenuBar();
		ItemMenu[] menuItem = new ItemMenu[] {
				new ItemMenu("File", "file", new ItemMenu[] {
						new ItemMenu("New", DOC_NEW, "/icons/new16.gif"),
						new ItemMenu("Open...", DOC_OPEN, "/icons/open16.gif"),
						new ItemMenu(),
						new ItemMenu("Save", DOC_SAVE, "/icons/save16.gif"),
						new ItemMenu("Save as...", DOC_SAVE_AS),
						new ItemMenu("Save picture as...", DOC_EXPORT,
								"/icons/export16.gif"), new ItemMenu(),
						new ItemMenu("Exit", EXIT) }),
				new ItemMenu("Edit", "edit", new ItemMenu[] {
						new ItemMenu("Copy to clipboard", COPY,
								"/icons/copy16.gif"),
						new ItemMenu(),
						new ItemMenu("Resize document", RESIZE)/*,
						new ItemMenu("Preferences...", PREFERENCES,
								"/icons/hammer16.gif")*/ }),
				new ItemMenu("Help", "help", new ItemMenu[] {
						new ItemMenu("Help", HELP, "/icons/help16.gif"),
						new ItemMenu(), new ItemMenu("About", ABOUT) }) };
		for (ItemMenu i : menuItem)
			bar.add(i.createMenu(this));
		setJMenuBar(bar);

		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		gridPanel.requestFocus();
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				exitProgram();
			}
		});
		setSize(new Dimension(600, 500));
		setLocationRelativeTo(null);
		setVisible(true);
	}

	private void exitProgram() {
		if (askForSaveAndProceed()) {
			dispose();
			System.exit(0);
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			// UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			JFrame.setDefaultLookAndFeelDecorated(true);
			JDialog.setDefaultLookAndFeelDecorated(true);
			new Main();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	private void setWorkFile(File f) {
		workFile = f;
		setTitle(mainTitle + workFile.getAbsolutePath());
	}
	
	private void resizeDocument(Dimension d) {
		gridPanel.resizeCanvas(d);
		labelDim.setText(sizeText + d.width + " x " + d.height);
	}

	private boolean saveOperation() {
		if (workFile == null) {
			return handleFile(DOC_SAVE);
		} else {
			try {
				tree.save(workFile, gridPanel.getCanvasSize(), gridPanel
						.getGridWidth(), gridPanel.getGridHeight());
				return true;
			} catch (Exception exc) {
				JOptionPane.showMessageDialog(this, exc.getMessage(),
						"File Error", JOptionPane.ERROR_MESSAGE);
				exc.printStackTrace(System.err);
			}
		}
		return false;
	}

	private boolean askForSaveAndProceed() {
		if (!tree.hasChanged())
			return true;
		int resp = JOptionPane.showConfirmDialog(this,
				"Do you want to save the changes?", "Changed",
				JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
		if (resp == JOptionPane.CANCEL_OPTION) {
			return false;
		} else if (resp == JOptionPane.YES_OPTION) {
			return saveOperation();
		}
		return true;
	}

	private boolean handleFile(String operation) {
		JFileChooser chooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
				"Tree Standard Files (TSF)", "tsf");
		chooser.setFileFilter(filter);
		int resp = operation.equals(DOC_OPEN) ? chooser.showOpenDialog(this)
				: chooser.showSaveDialog(this);
		if (resp == JFileChooser.APPROVE_OPTION) {
			try {
				String k = chooser.getSelectedFile().getAbsolutePath();
				if (k.substring(k.length() - 3).compareToIgnoreCase("tsf") != 0)
					k += ".tsf";
				if (!operation.equals(DOC_OPEN)) {
					File toBeSaved = new File(k);
					if (toBeSaved.exists()) {
						int ans = JOptionPane.showConfirmDialog(this,
								"Are you sure you want to replace this file?",
								"Save", JOptionPane.YES_NO_OPTION,
								JOptionPane.WARNING_MESSAGE);
						if (ans == JOptionPane.NO_OPTION)
							return false;
					}
					tree.save(toBeSaved, gridPanel.getCanvasSize(), gridPanel
							.getGridWidth(), gridPanel.getGridHeight());
					if (workFile == null)
						setWorkFile(toBeSaved);
				} else {
					File toBeOpened = new File(k);
					Hashtable<String, Object> map = tree.open(toBeOpened);
					if (map == null)
						throw new Exception(
								"Error: information missing on file!");
					Font fontFile = (Font) map.get(Tree.DOC_FONT);
					fontCombo.setSelectedItem(fontFile.getName());
					sizeCombo.setSelectedItem("" + fontFile.getSize());
					int number = ((Integer) map.get(Tree.DOC_GRID_WIDTH))
							.intValue();
					gridPanel.setGridWidth(number);
					sliders.get(GRID_WIDTH).setValue(number);
					number = ((Integer) map.get(Tree.DOC_GRID_HEIGHT))
							.intValue();
					gridPanel.setGridHeight(number);
					sliders.get(GRID_HEIGHT).setValue(number);
					resizeDocument((Dimension) map.get(Tree.DOC_DIMENSION));
					gridPanel.refresh();
					setWorkFile(toBeOpened);
				}
				return true;
			} catch (Exception exc) {
				JOptionPane.showMessageDialog(this, exc.getMessage(),
						"File Error", JOptionPane.ERROR_MESSAGE);
				exc.printStackTrace(System.err);
			}
		}
		return false;
	}

	private void exportImage() {
		String[] exts = new String[] { "JPG", "GIF", "PNG", "BMP" };
		String ext = (String) JOptionPane.showInputDialog(this,
				"Choose the file format:", "Export image",
				JOptionPane.QUESTION_MESSAGE, null, exts, "PNG");
		if (ext == null)
			return;

		JFileChooser chooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
				"Picture (" + ext + ")", ext.toLowerCase());
		chooser.setFileFilter(filter);
		int resp = chooser.showSaveDialog(this);
		if (resp == JFileChooser.APPROVE_OPTION) {
			try {
				String k = chooser.getSelectedFile().getAbsolutePath();
				if (k.substring(k.length() - 3).compareToIgnoreCase(ext) != 0)
					k += "." + ext.toLowerCase();
				tree.exportImage(gridPanel.getCanvasSize(), gridPanel
						.getGridWidth(), gridPanel.getGridHeight(),
						new File(k), ext.toLowerCase());
			} catch (Exception exc) {
				JOptionPane.showMessageDialog(this, exc.getMessage(),
						"Export Error", JOptionPane.ERROR_MESSAGE);
				exc.printStackTrace(System.err);
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent n) {
		String name = ((JComponent) n.getSource()).getName();
		if (name.compareTo(DOC_SAVE) == 0) {
			saveOperation();
		} else if (name.compareTo(DOC_SAVE_AS) == 0) {
			handleFile(DOC_SAVE_AS);
		} else if (name.compareTo(DOC_OPEN) == 0) {
			if (askForSaveAndProceed())
				handleFile(DOC_OPEN);
		} else if (name.compareTo(DOC_NEW) == 0) {
			if (askForSaveAndProceed()) {
				tree.newTree();
				Font fontNew = tree.getFont();
				fontCombo.setSelectedItem(fontNew.getName());
				sizeCombo.setSelectedItem("" + fontNew.getSize());
				gridPanel.setGridWidth(gridDefaultValue);
				gridPanel.setGridHeight(gridDefaultValue);
				sliders.get(GRID_WIDTH).setValue(gridDefaultValue);
				sliders.get(GRID_HEIGHT).setValue(gridDefaultValue);
				gridPanel.refresh();
				workFile = null;
				setTitle(mainTitle + "New file");
			}
		} else if (name.compareTo(DOC_EXPORT) == 0) {
			exportImage();
		} else if (name.compareTo(RESIZE) == 0) {
			DimensionDialog dd = new DimensionDialog(this, gridPanel
					.getCanvasSize());
			if (dd.hasChanged()) {
				resizeDocument(dd.getDimension());
			}
		} else if (name.compareTo(COPY) == 0) {
			tree.copyToClipboard(gridPanel.getCanvasSize(), gridPanel
					.getGridWidth(), gridPanel.getGridHeight());
		} else if (name.compareTo(EXIT) == 0) {
			exitProgram();
		} else if (name.compareTo(HELP) == 0) {
			JOptionPane.showMessageDialog(this, "<html><body>Please refer to the webpage:<br/>"
					+ "<a href='http://syntactictree.sourceforge.net/'>"
					+ "http://syntactictree.sourceforge.net/</a></body></html>", "Help",
					JOptionPane.INFORMATION_MESSAGE);
		} else if (name.compareTo(ABOUT) == 0) {
			JOptionPane.showMessageDialog(this, "<html><body>Syntactic Tree Designer v1.0<br>"
					+ "<a href='http://syntactictree.sourceforge.net/'>"
					+ "http://syntactictree.sourceforge.net/</a><br/><br/>"
					+ "Copyright (C) 2008 by Daniel Donadon<br/>"
					+ "Rights resreved under GPL license</body></html>", "About",
					JOptionPane.INFORMATION_MESSAGE);
		}
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		JSlider s = (JSlider) e.getSource();
		if (s.getName().compareTo(GRID_WIDTH) == 0)
			gridPanel.setGridWidth(s.getValue());
		else
			gridPanel.setGridHeight(s.getValue());
		gridPanel.refresh();
	}

}
