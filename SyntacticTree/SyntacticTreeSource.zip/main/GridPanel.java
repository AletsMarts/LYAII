package main;

import graphics.ScrollableCanvas;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import tree.Tree;

public class GridPanel extends ScrollableCanvas implements MouseListener,
		MouseMotionListener, ActionListener {

	private static final String ADD_ROOT = "addRoot";
	private static final String CHANGE_LABEL = "changeLabel";
	private static final String ADD_CHILD = "addChild";
	private static final String DETACH = "detach";
	private static final String REMOVE_TREE = "removeTree";
	private static final String XP_NEW_XP = "insertNewXP";
	private static final String XP_NEW_XP_NO_SPEC = "insertNewXPwithoutSpec";
	private static final String XP_ADJUNT = "adjunt";
	private static final String XP_ROOT = "addRootXP";
	private static final String XP_ROOT_NO_SPEC = "addRootwithoutSpec";
	private static final String INSERT_PARENT = "insertParent";
	private static final String ADD_COMPACTED_CHILD = "addCompacted";
	private static final String REMOVE_NODE = "removeNodeOnly";
	private static final String COMPACT = "compact";
	private static final String EXPAND = "expand";

	private static final long serialVersionUID = -8979592706880469853L;
	private int gridWidth, gridHeight;
	private JPopupMenu gridMenu, nodeMenu;
	private Tree tree;
	private JFrame frame;
	int x = 0, y = 0;
	private Point clickedPoint = null;
	private final int gridColor = 240;

	private JPopupMenu buildMenu(ItemMenu[] item) {
		JPopupMenu pop = new JPopupMenu();
		for (ItemMenu i : item) {
			if (i.isSeparator())
				pop.addSeparator();
			else
				pop.add(i.createMenu(this));
		}
		return pop;
	}

	public GridPanel(JFrame f, Dimension d, Tree t) {
		super(d);
		tree = t;
		frame = f;

		addMouseListener(this);
		addMouseMotionListener(this);

		ItemMenu[] gmItens = new ItemMenu[] {
				new ItemMenu("Add new root", ADD_ROOT),
				new ItemMenu(),
				new ItemMenu("X-Bar Theory", "xbar",
						new ItemMenu[] {
								new ItemMenu("Add new XP", XP_ROOT),
								new ItemMenu("Add new XP with no spec",
										XP_ROOT_NO_SPEC) }) };
		gridMenu = buildMenu(gmItens);

		ItemMenu[] nmItens = new ItemMenu[] {
				new ItemMenu("Edit label", CHANGE_LABEL),
				new ItemMenu(),
				new ItemMenu("Add a child", ADD_CHILD),
				new ItemMenu("Detach node from tree", DETACH),
				new ItemMenu("Remove node with subtree", REMOVE_TREE),
				new ItemMenu(),
				new ItemMenu("X-Bar Theory", "xbar2", new ItemMenu[] {
						new ItemMenu("Place an XP", XP_NEW_XP),
						new ItemMenu("Place an XP with no spec",
								XP_NEW_XP_NO_SPEC), new ItemMenu(),
						new ItemMenu("Insert adjunct", XP_ADJUNT) }),
				new ItemMenu(),
				new ItemMenu("More", "more", new ItemMenu[] {
						new ItemMenu("Insert a parent", INSERT_PARENT),
						new ItemMenu("Add a compacted child",
								ADD_COMPACTED_CHILD), new ItemMenu(),
						new ItemMenu("Remove node only", REMOVE_NODE),
						new ItemMenu(),
						new ItemMenu("Compact subtree", COMPACT),
						new ItemMenu("Expand subtree", EXPAND) }) };
		nodeMenu = buildMenu(nmItens);
	}

	public int getGridWidth() {
		return gridWidth;
	}

	public void setGridWidth(int gridWidth) {
		this.gridWidth = gridWidth;
	}

	public int getGridHeight() {
		return gridHeight;
	}

	public void setGridHeight(int gridHeight) {
		this.gridHeight = gridHeight;
	}

	@Override
	public void draw(Graphics2D go) {
		Dimension d = getCanvasSize();
		go.setBackground(Color.WHITE);
		go.clearRect(0, 0, d.width, d.height);
		go.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		int i;
		go.setColor(new Color(gridColor, gridColor, gridColor));
		for (i = gridWidth; i <= d.width; i += gridWidth)
			go.drawLine(i, 0, i, d.height);
		for (i = gridHeight; i <= d.height; i += gridHeight)
			go.drawLine(0, i, d.width, i);

		tree.draw(go, gridWidth, gridHeight);
	}

	public Point getCorrectPoint(MouseEvent e) {
		int px = e.getX() + getViewport().getViewPosition().x;
		int py = e.getY() + getViewport().getViewPosition().y;
		return new Point(px, py);
	}

	public Point getPointOnGrade(MouseEvent e) {
		Point c = getCorrectPoint(e);
		int px = Math.round(c.x / (float) gridWidth);
		int py = Math.round(c.y / (float) gridHeight);
		return new Point(px, py);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		clickedPoint = getPointOnGrade(e);
		if (tree.hasNodeSelected()) {
			if (e.getButton() == MouseEvent.BUTTON3) {
				nodeMenu.show(e.getComponent(), e.getX(), e.getY());
			} else if (e.getButton() == MouseEvent.BUTTON1
					&& e.getClickCount() > 1) {
				tree.changeLabel(frame);
			}
		} else {
			if (e.getButton() == MouseEvent.BUTTON3) {
				gridMenu.show(e.getComponent(), e.getX(), e.getY());
			}
		}
		refresh();
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// Not implemented
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// Not implemented
	}

	@Override
	public void mousePressed(MouseEvent e) {
		tree.selectNode(getPointOnGrade(e), getCorrectPoint(e), gridWidth,
				gridHeight);
		refresh();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if (tree.isThereSomeone(getPointOnGrade(e))) {
			boolean notMerged = true;
			if (tree.isPossibleToMerge()) {
				int ans = JOptionPane
						.showConfirmDialog(this,
								"Do you want to merge these two nodes?",
								"Merging", JOptionPane.YES_NO_OPTION,
								JOptionPane.QUESTION_MESSAGE);
				if (ans == JOptionPane.YES_OPTION) {
					tree.mergeInPosition();
					notMerged = false;
				}
			} else {
				JOptionPane.showMessageDialog(this,
						"It is not possible to merge these two nodes!",
						"Merging error", JOptionPane.ERROR_MESSAGE);
			}
			if (notMerged) {
				Point p = getPointOnGrade(e);
				p.y += 2;
				tree.setNewPosition(p);
			}
		} else if (tree.hasNodeSelected()
				&& e.getButton() == MouseEvent.BUTTON3)
			nodeMenu.show(e.getComponent(), e.getX(), e.getY());
		refresh();
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		if (tree.hasNodeSelected()) { // && e.getButton() == MouseEvent.BUTTON1
										// ) {
			tree.setNewPosition(getPointOnGrade(e));
			refresh();
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String name = ((JComponent) e.getSource()).getName();
		if (name.compareTo(ADD_ROOT) == 0) {
			String s = JOptionPane.showInputDialog(this,
					"Type the new root node's label:", "New root",
					JOptionPane.QUESTION_MESSAGE);
			if (s != null) {
				tree.addNewRoot(clickedPoint, s);
			}
		} else if (name.compareTo(CHANGE_LABEL) == 0) {
			tree.changeLabel(frame);
		} else if (name.compareTo(ADD_CHILD) == 0) {
			String s = JOptionPane.showInputDialog(this,
					"Type the new child's label:", "New child",
					JOptionPane.QUESTION_MESSAGE);
			if (s != null) {
				tree.addNewChild(s);
			}
		} else if (name.compareTo(DETACH) == 0) {
			tree.detachFromTree();
		} else if (name.compareTo(REMOVE_TREE) == 0) {
			int ans = JOptionPane
					.showConfirmDialog(
							this,
							"Are you sure you want to remove this node and its subtree?",
							"Remove subtree", JOptionPane.YES_NO_OPTION,
							JOptionPane.WARNING_MESSAGE);
			if (ans == JOptionPane.YES_OPTION)
				tree.removeFromTree();
		} else if (name.compareTo(XP_NEW_XP) == 0
				|| name.compareTo(XP_NEW_XP_NO_SPEC) == 0) {
			if (!tree.selectedNodeIsLeaf())
				JOptionPane.showMessageDialog(this,
						"Cannot place an XP on a parental node!\n"
								+ "Select a leaf node instead!", "New XP",
						JOptionPane.ERROR_MESSAGE);
			else {
				String s = JOptionPane.showInputDialog(this,
						"Type the new XP's category (e.g. V or N):", "New XP",
						JOptionPane.QUESTION_MESSAGE);
				if (s != null) {
					tree.placeNewXstructure(s, name.compareTo(XP_NEW_XP) == 0);
				}
			}
		} else if (name.compareTo(XP_ROOT) == 0
				|| name.compareTo(XP_ROOT_NO_SPEC) == 0) {
			String s = JOptionPane.showInputDialog(this,
					"Type the new XP's category (e.g. V or N):", "New XP",
					JOptionPane.QUESTION_MESSAGE);
			if (s != null) {
				tree.addNewXstructure(clickedPoint, s,
						name.compareTo(XP_ROOT) == 0);
			}
		} else if (name.compareTo(XP_ADJUNT) == 0) {
			tree.insertAdjunct();
		} else if (name.compareTo(INSERT_PARENT) == 0) {
			tree.insertParent();
		} else if (name.compareTo(ADD_COMPACTED_CHILD) == 0) {
			String s = JOptionPane.showInputDialog(this,
					"Type the new compacted child's label:",
					"New compacted child", JOptionPane.QUESTION_MESSAGE);
			if (s != null) {
				tree.addCompactedChild(s);
			}
		} else if (name.compareTo(COMPACT) == 0 || name.compareTo(EXPAND) == 0) {
			tree.setNodeCompacted(name.compareTo(COMPACT) == 0);
		} else if (name.compareTo(REMOVE_NODE) == 0) {
			if (!tree.removeNodeOnly()) {
				JOptionPane
						.showMessageDialog(
								this,
								"Cannot remove an intermediate node with more than one child!\n"
										+ "Try detaching this subtree and removing the head node.",
								"Remove node error", JOptionPane.ERROR_MESSAGE);
			}
		}
		refresh();
	}
}